import React from 'react';

let outBox =(props) => {

    return (<div><p>{props.output}</p></div>)
          

};

export default outBox;